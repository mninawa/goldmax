﻿using MongoDB.Bson;
using MongoDB.Driver;
using MongoSeeder.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Text.Json;
namespace MongoSeeder
{
    class Program
    {
        const string connectionUri = "mongodb+srv://mninawa:cdL6YEQTB0ATL0nl@uzima.zcnjkx3.mongodb.net/?retryWrites=true&w=majority&appName=uzima";

        static void Main(string[] args)
        {
           // CustomerSeed();
            MenuSeed();
            //OrderSeed();
        }
        
        static void CustomerSeed()
        {
           var settings = MongoClientSettings.FromConnectionString(connectionUri);
            settings.ServerApi = new ServerApi(ServerApiVersion.V1);
            var client = new MongoClient(settings);
            
            IMongoDatabase db = client.GetDatabase("customer");
            IMongoCollection<Customer> collection = db.GetCollection<Customer>("customer");
            
            List<Customer> customer;
            using (StreamReader r = new StreamReader("/Users/paige/blue/mongodb-seeder/MongoSeeder/Data/1-customers/customer.json"))  
            {  
                string json = r.ReadToEnd();  
                customer = JsonSerializer.Deserialize<List<Customer>>(json);  
            }  
            
            collection.InsertMany(customer);
            Console.WriteLine("customer collection has been created");
        }
        
        static void MenuSeed()
        {
            var settings = MongoClientSettings.FromConnectionString(connectionUri);
            settings.ServerApi = new ServerApi(ServerApiVersion.V1);
            var client = new MongoClient(settings);
            
            IMongoDatabase db = client.GetDatabase("menu");
            IMongoCollection<Menu> collection = db.GetCollection<Menu>("menu");
            
            var menu  = new List<Menu>();
            using (StreamReader r = new StreamReader("/Users/paige/blue/mongodb-seeder/MongoSeeder/Data/2-menus/menu.json"))  
            {  
                string json = r.ReadToEnd();  
                menu = JsonSerializer.Deserialize<List<Menu>>(json);  
            }  
            
            collection.InsertMany(menu);
            Console.WriteLine("menu collection has been created");
 
        }
        
        static void OrderSeed()
        {
            var settings = MongoClientSettings.FromConnectionString(connectionUri);
            settings.ServerApi = new ServerApi(ServerApiVersion.V1);
            var client = new MongoClient(settings);
            
            IMongoDatabase db = client.GetDatabase("order");
            IMongoCollection<Order> collection = db.GetCollection<Order>("order");
            
            var order  = new List<Order>();
            using (StreamReader r = new StreamReader("/Users/paige/blue/mongodb-seeder/MongoSeeder/Data/3-orders/order.json"))  
            {  
                string json = r.ReadToEnd();  
                order = JsonSerializer.Deserialize<List<Order>>(json);  
            }  
            
            collection.InsertMany(order);
            Console.WriteLine("order collection has been created");
        }
    }
}
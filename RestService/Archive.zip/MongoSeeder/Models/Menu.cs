using System.Text.Json.Serialization;
using MongoDB.Bson.Serialization.Attributes;

namespace MongoSeeder.Models;

public class Menu
{
    [BsonElement("name")]
    [JsonPropertyName("name")]
    public string Name { get; set; }

    [BsonElement("price")]
    [JsonPropertyName("price")]
    public double Price { get; set; }

    [BsonElement("category")]
    [JsonPropertyName("category")]
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public Category Categories { get; set; }

}
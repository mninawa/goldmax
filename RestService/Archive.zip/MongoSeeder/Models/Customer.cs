using MongoDB.Bson.Serialization.Attributes;
using System.Text.Json.Serialization;
using System.Text.Json.Serialization;

namespace MongoSeeder.Models
{
    public class Customer
    {
        [BsonElement("name")]
        [JsonPropertyName("name")]
        public string Name { get; set; }

        [BsonElement("lastname")]
        [JsonPropertyName("lastname")]
        public string Lastname { get; set; }

        [BsonElement("email")]
        [JsonPropertyName("email")]
        [BsonRequired]
        public string Email { get; set; }
        [JsonPropertyName("password")]
        [BsonElement("password")]
        public string Password { get; set; }
    }
}
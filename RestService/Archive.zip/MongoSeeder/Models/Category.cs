using System.Runtime.Serialization;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace MongoSeeder.Models;

public enum Category 
{
    [BsonRepresentation(BsonType.String)]
    [EnumMember(Value = "firstCourse")]
    firstCourse, 
    [BsonRepresentation(BsonType.String)]
    [EnumMember(Value = "mainCourse")]
    mainCourse
}
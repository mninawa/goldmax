using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace MongoSeeder.Models;

public class Order
{
    [BsonElement("orderdetail")]
    [JsonPropertyName("orderdetail")]
    public List<ObjectId> OrderDetail { get; set; }

    [BsonElement("customer")]
    [JsonPropertyName("customer")]
    public ObjectId Customer { get; set; }

    [BsonElement("date")]
    [JsonPropertyName("date")]
    public DateTime Date { get; set; }
}
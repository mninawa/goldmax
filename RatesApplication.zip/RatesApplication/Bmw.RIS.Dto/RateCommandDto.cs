﻿namespace Bmw.RIS.Dto;

public enum RateCommandDto
{
    None = 0,
    StartCalculate = 1,
    EndCalculate = 2,
}
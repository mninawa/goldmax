﻿using Microsoft.Extensions.Logging;
using Bmw.RIS.Dto;

namespace Bmw.RIS.Command.Services;

public class CommandService : ICommandService
{
    protected CommandService(ILogger<CommandService> logger)
    {
        Logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    protected ILogger<CommandService> Logger { get; }
    public async Task SaveRate(RateDataDto rateData)
    {
        await Task.Yield();
    }
}
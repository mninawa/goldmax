﻿using Bmw.RIS.Dto;

namespace Bmw.RIS.Command.Services;

public interface ICommandService
{
    Task SaveRate(RateDataDto rateData);
}
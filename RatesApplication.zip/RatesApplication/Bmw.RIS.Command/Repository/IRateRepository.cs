﻿using Bmw.RIS.Dto;

namespace Bmw.RIS.Command.Repository;

public interface IRateRepository
{
    Task InsertOrUpdateRate(RateDataDto rate, CancellationToken ct);
    Task InsertOrUpdateRatesAsync(ICollection<RateDataDto> rates, CancellationToken ct);
}
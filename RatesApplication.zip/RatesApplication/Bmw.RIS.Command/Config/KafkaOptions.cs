﻿namespace Bmw.RIS.Command.Config;

public class KafkaOptions
{
    public const string Kafka = "Kafka";

    public string BrokerList { get; set; } = default!;

    public string RatesCallbackTopicName { get; set; } = default!;

    public string GroupId { get; set; } = default!;

    

}
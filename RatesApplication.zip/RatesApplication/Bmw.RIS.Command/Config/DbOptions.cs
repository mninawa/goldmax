﻿namespace Bmw.RIS.Command.Config;

public class DbOptions
{
    public const string Db = "Db";

    public string? ConnectionString { get; set; }

}
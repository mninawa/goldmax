﻿using Bmw.RIS.Dto;

namespace Bmw.RIS.Calculator.Repository;

public interface IRateRepository
{
    void Reset();
    ICollection<RateDataDto> GetRates();
    void AddRate(RateDataDto rate);
}
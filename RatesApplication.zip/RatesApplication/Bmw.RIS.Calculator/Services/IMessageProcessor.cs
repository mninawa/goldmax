﻿using Bmw.RIS.Dto;

namespace Bmw.RIS.Calculator.Services;

public interface IMessageProcessor
{
    void Process(string? message, CancellationToken ct);
}
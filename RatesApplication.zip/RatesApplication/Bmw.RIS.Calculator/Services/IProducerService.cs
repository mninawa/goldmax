﻿using Bmw.RIS.Dto;

namespace Bmw.RIS.Calculator.Services;

public interface IProducerService
{
    void SendRates(ICollection<RateDataDto> rates, CancellationToken ct);
}
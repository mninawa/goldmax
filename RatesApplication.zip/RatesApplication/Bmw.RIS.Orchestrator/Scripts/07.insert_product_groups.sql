﻿INSERT INTO public."ProductGroup"("Code", "Name")
	VALUES 
	('T01', 'Каучуки'),
	('T02', 'Полиолефины'),
	('T02', 'Наливная химия')
	
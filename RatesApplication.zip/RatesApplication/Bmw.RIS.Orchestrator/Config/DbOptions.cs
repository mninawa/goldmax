﻿namespace Bmw.RIS.Orchestrator.Config;

public class DbOptions
{
    public const string Db = "Db";

    public string? ConnectionString { get; set; }

}
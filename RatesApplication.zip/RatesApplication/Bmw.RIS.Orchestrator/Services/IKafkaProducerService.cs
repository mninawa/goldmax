﻿using Bmw.RIS.Dto;

namespace Bmw.RIS.Orchestrator.Services;

public interface IKafkaProducerService
{
    void SendRates(IEnumerable<RateDataDto> rate, CancellationToken ct);
    void SendCommand(RateCommandDto command, CancellationToken ct);
}